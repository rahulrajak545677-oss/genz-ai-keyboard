# Gen Z AI Keyboard

An Android keyboard (IME) built with Kotlin + Jetpack Compose: Gen Z themes, a
slang long-press menu, and AI grammar correction that keeps your voice.

## Build it from GitHub (no Android Studio needed)

1. Create a new repo on GitHub and push this project to it (`main` branch).
2. Open the repo's **Actions** tab → **Build APK** runs automatically on every
   push (or click **Run workflow**).
3. When the run finishes, open it and download **genz-keyboard-debug-apk** from
   the *Artifacts* section. Unzip it to get `app-debug.apk`.
4. Install the APK on your phone (allow "install unknown apps" when asked).
5. Enable it: Settings → System → Languages & input → On-screen keyboard →
   Manage keyboards → **Gen Z Keyboard**. Switch to it from any text field with
   the keyboard-switch icon.

It's a **debug-signed** APK — fine for sideloading and testing. A Play Store
release would need your own signing key (never commit `*.jks` / `*.keystore`;
`.gitignore` already blocks them).

### Build locally instead

Open the folder in Android Studio (it uses the Gradle wrapper), or run
`./gradlew assembleDebug` with JDK 17 and the Android SDK installed. The APK
lands in `app/build/outputs/apk/debug/`.

## Before the correction feature will work

`CorrectionNetwork.BASE_URL` in
`app/src/main/java/com/genzkeyboard/app/correction/CorrectionApi.kt` is a
placeholder. Point it at a server you control that holds your AI API key and
exposes `POST /correct` accepting `{"text": "...", "level": 0|1|2}` and
returning `{"corrected": "..."}`. A small serverless function (Cloudflare
Worker, Vercel function, Cloud Run) forwarding the prompt below works well:

> "Fix only spelling, grammar, and punctuation in the following text.
> Preserve the author's tone, slang, casing, and sentence length. Do not
> rephrase for flow or add formality. Make the minimum edit necessary.
> Return only the corrected text, nothing else. Text: {text}"

Never embed your AI provider's API key in the app. Until the URL is set, the
keyboard still works; correction calls just fail silently.

## Project layout

```
.github/workflows/build-apk.yml        → CI: builds the debug APK
settings.gradle.kts, build.gradle.kts  → Gradle setup (AGP 8.7.3, Kotlin 2.0.21)
gradle.properties, gradlew, gradle/    → Gradle config + wrapper (Gradle 8.9)
app/build.gradle.kts                   → app module + dependencies
app/src/main/AndroidManifest.xml       → IME service, settings activity, permissions
app/src/main/res/                      → method.xml (IME descriptor), strings, icon

app/src/main/java/com/genzkeyboard/app/
  ime/GenZInputMethodService.kt        → the keyboard service: input handling,
                                          password-field detection, correction
                                          pipeline wiring, typing sounds
  ime/ui/KeyboardRoot.kt               → Compose UI: letters/symbols pages,
                                          suggestion bar, long-press slang menu
  ime/theme/KeyboardTheme.kt           → theme system (Midnight Neon, Cyber, Y2K)
  correction/CorrectionApi.kt          → Retrofit interface + models for your backend
  correction/CorrectionEngine.kt       → debounce buffer, API calls, minimal-diff patching
  settings/SettingsDataStore.kt        → SettingsRepository: persists theme,
                                          correction level/toggle, typing sounds,
                                          accept/reject counts (DataStore)
  settings/SettingsActivity.kt         → theme picker, correction controls,
                                          "vibe stat" card (also the launcher icon)
  settings/ComposeUtils.kt             → small Compose helpers used by Settings
```

## How it fits together

1. User types → `GenZInputMethodService` commits each char via `InputConnection`
   and reads back the current sentence.
2. That sentence goes to `CorrectionEngine`, which debounces (600ms) or fires
   immediately on sentence-ending punctuation, then calls your backend via
   `CorrectionApi`.
3. If the corrected text differs, it shows as one suggestion chip in the
   suggestion bar. Tapping it applies only the changed span (`TextDiff`),
   not the whole sentence — cursor position stays sane.
4. Every accept/reject updates a running ratio, shown back in Settings as a
   lighthearted "vibe stat."
5. If the focused field is a password field (checked via `EditorInfo.inputType`
   in `onStartInputView`), **none of this runs** — nothing gets buffered or
   sent anywhere for that field.
6. Theme, correction level/toggle, and typing-sounds choices made in
   `SettingsActivity` are persisted via DataStore and picked up live by the
   running keyboard service through Kotlin Flows.

## What's intentionally still manual

- The backend proxy itself (see above) — this repo only has the client side.
- A real click sound for typing sounds: drop a short `key_click.wav`/`.ogg` in
  `app/src/main/res/raw/`, then uncomment the `soundPool?.load(...)` line in
  `GenZInputMethodService.setupSoundPool()` and add `import com.genzkeyboard.app.R`.
- A numbers-row long-press-for-symbols shortcut and multi-language layouts,
  if you want those later.

## Features

- ✅ Gen Z theming (3 themes, swappable, more are one `KeyboardTheme` object away)
- ✅ Press-scale + haptic key feedback, animated suggestion chip entrance
- ✅ Grammar correction with a "sounds like a person" prompt, minimal-diff apply
- ✅ Password/sensitive-field detection — those fields are skipped entirely
- ✅ Settings persistence via DataStore (theme, correction level/toggle, sounds)
- ✅ Typing sounds toggle (wire up the actual sound file, see above)
- ✅ Slang/abbreviation long-press menu on the space bar
- ✅ "Vibe stat" — accept-rate card in Settings
- ✅ Symbols/numbers keyboard page
