package com.genzkeyboard.app.settings

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.genzkeyboard.app.ime.theme.KeyboardTheme
import com.genzkeyboard.app.ime.theme.KeyboardThemes
import kotlinx.coroutines.launch

/**
 * Where the user picks a theme and tunes correction aggressiveness.
 * Every control here reads/writes through SettingsRepository (DataStore),
 * so changes persist and the IME picks them up via the Flows it collects.
 */
class SettingsActivity : ComponentActivity() {

    private lateinit var settings: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsRepository(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                SettingsScreen(settings, lifecycleScope)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class) // TopAppBar is still experimental in material3
@Composable
fun SettingsScreen(settings: SettingsRepository, scope: kotlinx.coroutines.CoroutineScope) {
    val themeName by settings.themeName.collectAsStateWithLifecycleCompat("Midnight Neon")
    val correctionLevel by settings.correctionLevel.collectAsStateWithLifecycleCompat(1)
    val correctionEnabled by settings.correctionEnabled.collectAsStateWithLifecycleCompat(true)
    val typingSounds by settings.typingSounds.collectAsStateWithLifecycleCompat(false)
    val acceptRate by settings.acceptRatePercent.collectAsStateWithLifecycleCompat(100)

    val selectedTheme = KeyboardThemes.all.firstOrNull { it.name == themeName } ?: KeyboardThemes.MidnightNeon

    Scaffold(topBar = { TopAppBar(title = { Text("Keyboard Settings") }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
        ) {
            VibeStatCard(acceptRate)

            Spacer(Modifier.height(20.dp))
            Text("Theme", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.height(100.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(KeyboardThemes.all) { theme ->
                    ThemeSwatch(
                        theme = theme,
                        selected = theme == selectedTheme,
                        onClick = { scope.launch { settings.setThemeName(theme.name) } }
                    )
                }
            }

            Spacer(Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Grammar correction", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = correctionEnabled,
                    onCheckedChange = { scope.launch { settings.setCorrectionEnabled(it) } }
                )
            }

            Spacer(Modifier.height(12.dp))
            Text("Correction level", style = MaterialTheme.typography.titleMedium)
            Column {
                listOf("Spelling only", "Spelling + grammar", "Spelling + grammar + punctuation")
                    .forEachIndexed { index, label ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = correctionLevel == index,
                                enabled = correctionEnabled,
                                onClick = { scope.launch { settings.setCorrectionLevel(index) } }
                            )
                            Text(label)
                        }
                    }
            }

            Spacer(Modifier.height(24.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Typing sounds", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = typingSounds,
                    onCheckedChange = { scope.launch { settings.setTypingSounds(it) } }
                )
            }

            Spacer(Modifier.height(24.dp))
            Text(
                "Long-press the space bar for quick slang (ngl, fr fr, 💀, and more).",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun VibeStatCard(acceptRate: Int) {
    val label = when {
        acceptRate >= 90 -> "clean typer ✨"
        acceptRate >= 70 -> "pretty solid 🙂"
        acceptRate >= 40 -> "needs work 😅"
        else -> "chaotic typing 💀"
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp)
    ) {
        Column {
            Text("your vibe this week", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(4.dp))
            Text("$acceptRate% $label", style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
private fun ThemeSwatch(theme: KeyboardTheme, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(80.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(theme.background)
            .then(
                if (selected) Modifier.background(theme.keyGlow.copy(alpha = 0.15f)) else Modifier
            )
            .then(Modifier.clickableNoRipple(onClick))
    ) {
        Text(
            theme.name,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(4.dp),
            color = theme.keyText,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
