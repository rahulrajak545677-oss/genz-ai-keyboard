package com.genzkeyboard.app.ime

import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.SoundPool
import android.text.InputType
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.genzkeyboard.app.correction.CorrectionEngine
import com.genzkeyboard.app.correction.TextDiff
import com.genzkeyboard.app.ime.theme.KeyboardThemes
import com.genzkeyboard.app.ime.theme.LocalKeyboardTheme
import com.genzkeyboard.app.ime.ui.Suggestion
import com.genzkeyboard.app.settings.SettingsRepository
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

/**
 * Entry point Android binds to when the user selects this keyboard.
 * Compose-in-IME needs manual Lifecycle/ViewModelStore/SavedStateRegistry wiring
 * because InputMethodService doesn't provide these owners out of the box.
 */
class GenZInputMethodService :
    InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    private val store = ViewModelStore()
    override val viewModelStore: ViewModelStore get() = store

    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    private lateinit var settings: SettingsRepository
    private lateinit var correctionEngine: CorrectionEngine
    private var soundPool: SoundPool? = null
    private var clickSoundId: Int = 0

    private var currentThemeState = mutableStateOf(KeyboardThemes.MidnightNeon)
    private var suggestionsState = mutableStateOf<List<Suggestion>>(emptyList())
    private var typingSoundsEnabled = false
    private var correctionLevel = 1
    private var correctionEnabled = true

    /** True while the focused field is a password/sensitive field — nothing gets sent to the correction API then. */
    private var isSensitiveField = false

    /** Running count for the "vibe stat" shown in Settings (cleanest typer this week, etc). */
    private var acceptedCount = 0
    private var rejectedOrIgnoredCount = 0

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

        settings = SettingsRepository(applicationContext)
        correctionEngine = CorrectionEngine(
            scope = lifecycleScope,
            isCorrectionEnabled = { correctionEnabled },
            correctionLevel = { correctionLevel }
        )

        // Keep local fields in sync with whatever the user picks in SettingsActivity.
        settings.themeName.onEach { name ->
            currentThemeState.value = KeyboardThemes.all.firstOrNull { it.name == name }
                ?: KeyboardThemes.MidnightNeon
        }.launchIn(lifecycleScope)

        settings.correctionLevel.onEach { correctionLevel = it }.launchIn(lifecycleScope)
        settings.correctionEnabled.onEach { correctionEnabled = it }.launchIn(lifecycleScope)
        settings.typingSounds.onEach { typingSoundsEnabled = it }.launchIn(lifecycleScope)

        correctionEngine.suggestions.onEach { suggestionsState.value = it }.launchIn(lifecycleScope)

        setupSoundPool()
    }

    private fun setupSoundPool() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder().setAudioAttributes(attrs).setMaxStreams(4).build()
        // Drop a short click .ogg/.wav at res/raw/key_click and uncomment:
        // clickSoundId = soundPool?.load(this, R.raw.key_click, 1) ?: 0
    }

    /** Detects password/sensitive fields so their contents never get buffered or sent anywhere. */
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val variation = info?.inputType?.and(InputType.TYPE_MASK_VARIATION) ?: 0
        val cls = info?.inputType?.and(InputType.TYPE_MASK_CLASS) ?: 0
        isSensitiveField = (cls == InputType.TYPE_CLASS_TEXT && (
            variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            )) || cls == InputType.TYPE_CLASS_NUMBER && (info?.inputType
            ?.and(InputType.TYPE_MASK_VARIATION) == InputType.TYPE_NUMBER_VARIATION_PASSWORD)

        if (isSensitiveField) suggestionsState.value = emptyList()
    }

    override fun onCreateInputView(): View {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        // An IME has no Activity, so nothing installs the Lifecycle / ViewModelStore / SavedState
        // owners Compose looks for. Compose resolves them from the top-most view of the window
        // (the decor view), not from the ComposeView itself, so they must be set there too —
        // otherwise it crashes with "ViewTreeLifecycleOwner not found".
        window?.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@GenZInputMethodService)
            setViewTreeViewModelStoreOwner(this@GenZInputMethodService)
            setViewTreeSavedStateRegistryOwner(this@GenZInputMethodService)

            setContent {
                val theme by currentThemeState
                val suggestions by suggestionsState
                CompositionLocalProvider(LocalKeyboardTheme provides theme) {
                    com.genzkeyboard.app.ime.ui.KeyboardRoot(
                        onKey = { char -> handleKeyPress(char) },
                        onBackspace = { handleBackspace() },
                        onEnter = { handleEnter() },
                        onSpace = { handleSpace() },
                        onInsertText = { text -> handleInsertText(text) },
                        suggestions = suggestions,
                        onAcceptSuggestion = { suggestion -> handleAcceptSuggestion(suggestion) },
                        modifier = Modifier
                    )
                }
            }
        }
        return composeView
    }

    private fun playClickSound() {
        if (typingSoundsEnabled && clickSoundId != 0) {
            soundPool?.play(clickSoundId, 0.4f, 0.4f, 1, 0, 1f)
        }
    }

    /** Reads back the sentence currently before the cursor, used to feed the correction engine. */
    private fun currentSentenceBuffer(): String {
        val ic = currentInputConnection ?: return ""
        // Look back up to 200 chars and trim to the start of the current sentence.
        val before = ic.getTextBeforeCursor(200, 0)?.toString() ?: ""
        val sentenceStart = before.lastIndexOfAny(charArrayOf('.', '!', '?', '\n')).let {
            if (it == -1) 0 else it + 1
        }
        return before.substring(sentenceStart).trimStart()
    }

    private fun handleKeyPress(char: Char) {
        currentInputConnection?.commitText(char.toString(), 1)
        playClickSound()
        correctionEngine.onTextChanged(currentSentenceBuffer(), isSensitiveField)
    }

    private fun handleInsertText(text: String) {
        currentInputConnection?.commitText(text, 1)
        playClickSound()
    }

    private fun handleBackspace() {
        currentInputConnection?.deleteSurroundingText(1, 0)
        playClickSound()
        correctionEngine.onTextChanged(currentSentenceBuffer(), isSensitiveField)
    }

    private fun handleEnter() {
        currentInputConnection?.commitText("\n", 1)
        playClickSound()
        correctionEngine.onSentenceBoundary(currentSentenceBuffer(), isSensitiveField)
    }

    private fun handleSpace() {
        currentInputConnection?.commitText(" ", 1)
        playClickSound()
        correctionEngine.onTextChanged(currentSentenceBuffer(), isSensitiveField)
    }

    /** Replaces only the changed span (diffed) rather than retyping the whole sentence. */
    private fun handleAcceptSuggestion(suggestion: Suggestion) {
        val ic = currentInputConnection ?: return
        val old = currentSentenceBuffer()
        val span = TextDiff.diff(old, suggestion.text)

        val charsBeforeCursorToDelete = old.length - span.start
        ic.deleteSurroundingText(charsBeforeCursorToDelete, 0)
        ic.commitText(suggestion.text.substring(span.start), 1)

        acceptedCount++
        lifecycleScope.launch { settings.recordAccepted() }
        correctionEngine.clear()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        if (suggestionsState.value.isNotEmpty()) {
            rejectedOrIgnoredCount++
            lifecycleScope.launch { settings.recordRejected() }
        }
        correctionEngine.clear()
    }

    override fun onDestroy() {
        soundPool?.release()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        super.onDestroy()
    }
}
