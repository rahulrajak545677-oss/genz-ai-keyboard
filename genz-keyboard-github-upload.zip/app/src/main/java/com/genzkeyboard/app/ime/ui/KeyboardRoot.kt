package com.genzkeyboard.app.ime.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.genzkeyboard.app.ime.theme.LocalKeyboardTheme

/** Long-press-on-space quick phrases. Keeps the user's own voice instead of the AI's. */
private val slangPhrases = listOf("ngl", "fr fr", "lowkey", "istg", "no cap", "💀", "😭", "fym")

/**
 * Keyboard keys use their own interaction source (for the press-scale animation)
 * and no ripple, since a Material ripple looks out of place on a keycap.
 */
@Composable
private fun Modifier.clickableKey(
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() },
    onClick: () -> Unit
): Modifier = this.clickable(
    interactionSource = interactionSource,
    indication = null,
    onClick = onClick
)

/**
 * A correction suggestion. `text` is what the chip displays (the replacement
 * word/phrase); `range` is the span in the current buffer it replaces, so
 * acceptance can patch just that span via InputConnection.
 */
data class Suggestion(val text: String, val range: IntRange = IntRange.EMPTY)

private val letterRows = listOf(
    "q w e r t y u i o p",
    "a s d f g h j k l",
    "z x c v b n m"
)

private val symbolRowsPage1 = listOf(
    "1 2 3 4 5 6 7 8 9 0",
    "@ # \$ _ & - + ( ) /",
    "* \" ' : ; ! ? ~"
)

private val symbolRowsPage2 = listOf(
    "% \u00B0 \u00A9 \u00AE \u20AC \u00A3 \u00A5 \u00A2",
    "= { } [ ] | \\ < >",
    "\u00B7 , . ^ \u2022"
)

private enum class KeyboardPage { LETTERS, SYMBOLS_1, SYMBOLS_2 }

@Composable
fun KeyboardRoot(
    onKey: (Char) -> Unit,
    onBackspace: () -> Unit,
    onEnter: () -> Unit,
    onSpace: () -> Unit,
    modifier: Modifier = Modifier,
    suggestions: List<Suggestion> = emptyList(),
    onAcceptSuggestion: (Suggestion) -> Unit = {},
    onInsertText: (String) -> Unit = {}
) {
    val theme = LocalKeyboardTheme.current
    var shiftOn by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf(KeyboardPage.LETTERS) }
    var showSlangMenu by remember { mutableStateOf(false) }

    val activeRows = when (page) {
        KeyboardPage.LETTERS -> letterRows
        KeyboardPage.SYMBOLS_1 -> symbolRowsPage1
        KeyboardPage.SYMBOLS_2 -> symbolRowsPage2
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(theme.background)
            .padding(top = 6.dp, bottom = 10.dp)
    ) {
        SuggestionBar(suggestions = suggestions, onAccept = onAcceptSuggestion)

        Spacer(Modifier.height(6.dp))

        activeRows.forEachIndexed { index, row ->
            KeyRow(
                tokens = row.split(" "),
                shiftOn = shiftOn && page == KeyboardPage.LETTERS,
                onKey = onKey,
                extraStartContent = if (index == 2 && page == KeyboardPage.LETTERS) {
                    { ShiftKey(active = shiftOn) { shiftOn = !shiftOn } }
                } else null,
                extraEndContent = if (index == 2) {
                    { BackspaceKey(onBackspace) }
                } else null
            )
            Spacer(Modifier.height(6.dp))
        }

        AnimatedVisibility(
            visible = showSlangMenu,
            enter = fadeIn(tween(120)),
            exit = fadeOut(tween(100))
        ) {
            SlangMenu(
                onPick = { phrase ->
                    onInsertText(phrase)
                    showSlangMenu = false
                },
                onDismiss = { showSlangMenu = false }
            )
        }

        BottomRow(
            page = page,
            onPageChange = { page = it },
            onEnter = onEnter,
            onSpace = onSpace,
            onSpaceLongPress = { showSlangMenu = true }
        )
    }
}

@Composable
private fun SlangMenu(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val theme = LocalKeyboardTheme.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(theme.suggestionBarBackground)
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
    ) {
        slangPhrases.forEach { phrase ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(theme.suggestionChipBackground)
                    .then(Modifier.clickableKey { onPick(phrase) })
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(phrase, color = theme.suggestionChipText, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun SuggestionBar(
    suggestions: List<Suggestion>,
    onAccept: (Suggestion) -> Unit
) {
    val theme = LocalKeyboardTheme.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(40.dp)
            .background(theme.suggestionBarBackground),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Spacer(Modifier.width(4.dp))
        suggestions.forEach { suggestion ->
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(tween(180)) + slideInHorizontally(tween(180)) { it / 3 },
                exit = fadeOut(tween(120))
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(theme.suggestionChipBackground)
                        .then(Modifier.clickableKey { onAccept(suggestion) })
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(suggestion.text, color = theme.suggestionChipText, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun KeyRow(
    tokens: List<String>,
    shiftOn: Boolean,
    onKey: (Char) -> Unit,
    extraStartContent: (@Composable RowScope.() -> Unit)? = null,
    extraEndContent: (@Composable RowScope.() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally)
    ) {
        extraStartContent?.invoke(this)
        tokens.forEach { token ->
            val char = if (shiftOn) token.uppercase()[0] else token[0]
            LetterKey(char) { onKey(char) }
        }
        extraEndContent?.invoke(this)
    }
}

@Composable
private fun RowScope.LetterKey(char: Char, onClick: () -> Unit) {
    val theme = LocalKeyboardTheme.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val haptics = LocalHapticFeedback.current
    val scale by animateFloatAsState(if (isPressed) 0.9f else 1f, tween(80), label = "keyScale")

    Box(
        modifier = Modifier
            .weight(1f)
            .height(46.dp)
            .scale(scale)
            .clip(RoundedCornerShape(theme.keyCornerRadius))
            .background(if (isPressed) theme.keyBackgroundPressed else theme.keyBackground)
            .then(
                Modifier.clickableKey(interactionSource) {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(char.toString(), color = theme.keyText, fontSize = theme.fontSizeSp)
    }
}

@Composable
private fun ShiftKey(active: Boolean, onToggle: () -> Unit) {
    val theme = LocalKeyboardTheme.current
    Box(
        modifier = Modifier
            .width(46.dp)
            .height(46.dp)
            .clip(RoundedCornerShape(theme.keyCornerRadius))
            .background(if (active) theme.keyGlow.copy(alpha = 0.3f) else theme.keyBackground)
            .then(Modifier.clickableKey { onToggle() }),
        contentAlignment = Alignment.Center
    ) {
        Text("⇧", color = theme.keyText, fontSize = theme.fontSizeSp)
    }
}

@Composable
private fun BackspaceKey(onClick: () -> Unit) {
    val theme = LocalKeyboardTheme.current
    Box(
        modifier = Modifier
            .width(46.dp)
            .height(46.dp)
            .clip(RoundedCornerShape(theme.keyCornerRadius))
            .background(theme.keyBackground)
            .then(Modifier.clickableKey { onClick() }),
        contentAlignment = Alignment.Center
    ) {
        Text("⌫", color = theme.keyText, fontSize = theme.fontSizeSp)
    }
}

@Composable
private fun BottomRow(
    page: KeyboardPage,
    onPageChange: (KeyboardPage) -> Unit,
    onEnter: () -> Unit,
    onSpace: () -> Unit,
    onSpaceLongPress: () -> Unit
) {
    val theme = LocalKeyboardTheme.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Toggles between letters and the first symbols page.
        Box(
            modifier = Modifier
                .weight(1f)
                .height(46.dp)
                .clip(RoundedCornerShape(theme.keyCornerRadius))
                .background(theme.keyBackground)
                .then(Modifier.clickableKey {
                    onPageChange(if (page == KeyboardPage.LETTERS) KeyboardPage.SYMBOLS_1 else KeyboardPage.LETTERS)
                }),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (page == KeyboardPage.LETTERS) "?123" else "ABC",
                color = theme.keyText,
                fontSize = 13.sp
            )
        }

        // Only shown on a symbols page: flips between the two symbol sets.
        if (page != KeyboardPage.LETTERS) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(RoundedCornerShape(theme.keyCornerRadius))
                    .background(theme.keyBackground)
                    .then(Modifier.clickableKey {
                        onPageChange(if (page == KeyboardPage.SYMBOLS_1) KeyboardPage.SYMBOLS_2 else KeyboardPage.SYMBOLS_1)
                    }),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (page == KeyboardPage.SYMBOLS_1) "#+=" else "123",
                    color = theme.keyText,
                    fontSize = 13.sp
                )
            }
        }

        Box(
            modifier = Modifier
                .weight(if (page == KeyboardPage.LETTERS) 4f else 3f)
                .height(46.dp)
                .clip(RoundedCornerShape(theme.keyCornerRadius))
                .background(theme.keyBackground)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { onSpace() },
                        onLongPress = { onSpaceLongPress() }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Text("space", color = theme.keyText.copy(alpha = 0.6f), fontSize = 13.sp)
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .height(46.dp)
                .clip(RoundedCornerShape(theme.keyCornerRadius))
                .background(theme.accent)
                .then(Modifier.clickableKey { onEnter() }),
            contentAlignment = Alignment.Center
        ) {
            Text("↵", color = Color.White, fontSize = theme.fontSizeSp)
        }
    }
}
