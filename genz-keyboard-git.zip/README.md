# Gen Z AI Keyboard — Full Build

## What's here

```
AndroidManifest_snippet.xml            → paste into your app's AndroidManifest.xml
res/xml/method.xml                     → required IME descriptor

kotlin/ime/GenZInputMethodService.kt   → the keyboard service: input handling,
                                          password-field detection, correction
                                          pipeline wiring, typing sounds
kotlin/ime/ui/KeyboardRoot.kt          → Compose UI: letters/symbols pages,
                                          suggestion bar, long-press slang menu
kotlin/ime/theme/KeyboardTheme.kt      → theme system (Midnight Neon, Cyber, Y2K)

kotlin/correction/CorrectionApi.kt     → Retrofit interface + models for your backend
kotlin/correction/CorrectionEngine.kt  → debounce buffer, API calls, minimal-diff patching

kotlin/settings/SettingsDataStore.kt   → SettingsRepository: persists theme,
                                          correction level/toggle, typing sounds,
                                          accept/reject counts (DataStore)
kotlin/settings/SettingsActivity.kt    → theme picker, correction controls,
                                          "vibe stat" card
kotlin/settings/ComposeUtils.kt        → small Compose helpers used by Settings
```

## How it fits together

1. User types → `GenZInputMethodService` commits each char via `InputConnection`
   and reads back the current sentence.
2. That sentence goes to `CorrectionEngine`, which debounces (600ms) or fires
   immediately on sentence-ending punctuation, then calls your backend via
   `CorrectionApi`.
3. If the corrected text differs, it shows as one suggestion chip in the
   suggestion bar. Tapping it applies only the changed span (`TextDiff`),
   not the whole sentence — cursor position stays sane.
4. Every accept/reject updates a running ratio, shown back in Settings as a
   lighthearted "vibe stat."
5. If the focused field is a password field (checked via `EditorInfo.inputType`
   in `onStartInputView`), **none of this runs** — nothing gets buffered or
   sent anywhere for that field.
6. Theme, correction level/toggle, and typing-sounds choices made in
   `SettingsActivity` are persisted via DataStore and picked up live by the
   running keyboard service through Kotlin Flows.

## Setting up the project

1. New Android Studio project (Empty Compose Activity), package name
   `com.genzkeyboard.app` — or update every file's `package` line if you
   use something else.
2. Copy `kotlin/` into `app/src/main/java/com/genzkeyboard/app/...` matching
   the folder structure above.
3. Copy `res/xml/method.xml` into `app/src/main/res/xml/`.
4. Add the manifest snippet's `<service>` and `<uses-permission>` lines into
   `app/src/main/AndroidManifest.xml`. Also add `android.permission.INTERNET`
   (needed for the correction API calls).
5. Add a `keyboard_name` string to `res/values/strings.xml`.
6. (Optional, for typing sounds) drop a short click sound at
   `res/raw/key_click.wav` or `.ogg`, then uncomment the `soundPool?.load(...)`
   line in `GenZInputMethodService.setupSoundPool()` and add back
   `import com.genzkeyboard.app.R`.
7. `app/build.gradle.kts` dependencies:
   ```kotlin
   implementation("androidx.compose.ui:ui:1.7.0")
   implementation("androidx.compose.material3:material3:1.3.0")
   implementation("androidx.compose.material:material:1.7.0") // rememberRipple
   implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.0")
   implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.0")
   implementation("androidx.activity:activity-compose:1.9.0")
   implementation("androidx.datastore:datastore-preferences:1.1.1")
   implementation("com.squareup.retrofit2:retrofit:2.11.0")
   implementation("com.squareup.retrofit2:converter-gson:2.11.0")
   implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
   ```
   (versions illustrative — use whatever's current when you set the project up)
8. **Set up your backend before testing correction.** `CorrectionNetwork.BASE_URL`
   in `CorrectionApi.kt` must point at a server you control, which holds your
   AI API key and exposes a `POST /correct` endpoint accepting
   `{"text": "...", "level": 0|1|2}` and returning `{"corrected": "..."}`.
   A small serverless function (Cloudflare Worker, Vercel function, Cloud Run)
   that forwards the prompt below to your AI provider works well:
   > "Fix only spelling, grammar, and punctuation in the following text.
   > Preserve the author's tone, slang, casing, and sentence length. Do not
   > rephrase for flow or add formality. Make the minimum edit necessary.
   > Return only the corrected text, nothing else. Text: {text}"
9. Build, install, then: Settings → System → Languages & input → On-screen
   keyboard → Manage keyboards → enable "Gen Z Keyboard." Switch to it from
   any text field via the keyboard-switch icon.

## What's intentionally still manual

- The backend proxy itself (step 8 above) — this repo only has the client
  side. Never embed your AI provider's API key directly in the app.
- A real click sound file for typing sounds (step 6).
- A numbers-row long-press-for-symbols shortcut and multi-language layouts,
  if you want those later.

## Everything else from our earlier discussion is wired in

- ✅ Gen Z theming (3 themes, swappable, more are one `KeyboardTheme` object away)
- ✅ Press-scale + haptic key feedback, animated suggestion chip entrance
- ✅ Grammar correction with a "sounds like a person" prompt, minimal-diff apply
- ✅ Password/sensitive-field detection — those fields are skipped entirely
- ✅ Settings persistence via DataStore (theme, correction level/toggle, sounds)
- ✅ Typing sounds toggle (wire up the actual sound file per step 6)
- ✅ Slang/abbreviation long-press menu on the space bar
- ✅ "Vibe stat" — accept-rate card in Settings
- ✅ Symbols/numbers keyboard page
