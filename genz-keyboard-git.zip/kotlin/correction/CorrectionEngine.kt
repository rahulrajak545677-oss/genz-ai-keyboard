package com.genzkeyboard.app.correction

import com.genzkeyboard.app.ime.ui.Suggestion
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private const val DEBOUNCE_MS = 600L

/**
 * Owns the "what has the user typed since their last accepted/rejected
 * suggestion" buffer, debounces calls to the correction API, and exposes
 * the result as a single suggestion chip (the corrected sentence).
 *
 * Call `onTextChanged` on every commit (letter/space/backspace) with the
 * FULL current sentence (service reads it back via InputConnection), and
 * `cancelPending` on accept/reject so a stale response doesn't land late.
 */
class CorrectionEngine(
    private val scope: CoroutineScope,
    private val isCorrectionEnabled: () -> Boolean,
    private val correctionLevel: () -> Int
) {
    private val _suggestions = MutableStateFlow<List<Suggestion>>(emptyList())
    val suggestions: StateFlow<List<Suggestion>> = _suggestions.asStateFlow()

    private var pendingJob: Job? = null
    private var lastSentText: String = ""

    fun onTextChanged(currentSentence: String, isSensitiveField: Boolean) {
        if (!isCorrectionEnabled() || isSensitiveField) {
            clear()
            return
        }
        if (currentSentence.isBlank() || currentSentence == lastSentText) return

        pendingJob?.cancel()
        pendingJob = scope.launch {
            delay(DEBOUNCE_MS)
            runCorrection(currentSentence)
        }
    }

    /** Call immediately on sentence-ending punctuation or newline, skipping the debounce wait. */
    fun onSentenceBoundary(currentSentence: String, isSensitiveField: Boolean) {
        if (!isCorrectionEnabled() || isSensitiveField || currentSentence.isBlank()) return
        pendingJob?.cancel()
        pendingJob = scope.launch { runCorrection(currentSentence) }
    }

    private suspend fun runCorrection(text: String) {
        lastSentText = text
        runCatching {
            CorrectionNetwork.api.correct(CorrectionRequest(text = text, level = correctionLevel()))
        }.onSuccess { response ->
            if (response.corrected.trim() != text.trim()) {
                _suggestions.value = listOf(Suggestion(response.corrected))
            } else {
                _suggestions.value = emptyList()
            }
        }.onFailure {
            // Network/API error: fail silently, keep typing uninterrupted.
            _suggestions.value = emptyList()
        }
    }

    fun clear() {
        pendingJob?.cancel()
        _suggestions.value = emptyList()
    }
}

/**
 * Minimal diff: find the shared prefix and suffix between old and new text
 * so only the changed middle span gets replaced in the InputConnection,
 * keeping cursor position sane instead of retyping the whole sentence.
 */
object TextDiff {
    data class Span(val start: Int, val end: Int, val replacement: String)

    fun diff(old: String, new: String): Span {
        var prefix = 0
        while (prefix < old.length && prefix < new.length && old[prefix] == new[prefix]) prefix++

        var oldSuffix = old.length
        var newSuffix = new.length
        while (oldSuffix > prefix && newSuffix > prefix && old[oldSuffix - 1] == new[newSuffix - 1]) {
            oldSuffix--
            newSuffix--
        }

        return Span(
            start = prefix,
            end = oldSuffix,
            replacement = new.substring(prefix, newSuffix)
        )
    }
}
