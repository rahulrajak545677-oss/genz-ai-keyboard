package com.genzkeyboard.app.correction

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class CorrectionRequest(
    val text: String,
    /** 0 = spelling only, 1 = + grammar, 2 = + punctuation. Mirrors SettingsRepository.correctionLevel. */
    val level: Int
)

data class CorrectionResponse(
    val corrected: String
)

interface CorrectionApi {
    @POST("correct")
    suspend fun correct(@Body request: CorrectionRequest): CorrectionResponse
}

/**
 * IMPORTANT: this must point at YOUR OWN backend, which holds the AI API key
 * server-side and forwards requests to it. Never put an AI provider's API key
 * directly in this app — it would be extractable from the APK.
 *
 * Point BASE_URL at your deployed proxy (e.g. a small Cloudflare Worker /
 * Vercel function / Cloud Run service) that accepts {text, level} and returns
 * {corrected}.
 */
object CorrectionNetwork {
    private const val BASE_URL = "https://YOUR-BACKEND-HERE.example.com/"

    val api: CorrectionApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(CorrectionApi::class.java)
    }
}
