package com.genzkeyboard.app.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import kotlinx.coroutines.flow.Flow

/**
 * Thin wrapper so call sites don't need to import both collectAsState and
 * pass an initial value inline every time. Not lifecycle-aware in the strict
 * sense (plain collectAsState) — fine for a small Settings screen; swap for
 * androidx.lifecycle:lifecycle-runtime-compose's collectAsStateWithLifecycle
 * if you want pause/resume-aware collection.
 */
@Composable
fun <T> Flow<T>.collectAsStateWithLifecycleCompat(initial: T): State<T> =
    this.collectAsState(initial = initial)

@Composable
fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier {
    val interactionSource = remember { MutableInteractionSource() }
    return this.clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
}
