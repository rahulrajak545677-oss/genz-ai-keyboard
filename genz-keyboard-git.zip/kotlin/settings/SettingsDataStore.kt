package com.genzkeyboard.app.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "keyboard_settings")

/**
 * Single source of truth for user settings. The IME service and the
 * SettingsActivity both read/write through this, so a change made in
 * Settings shows up in the keyboard next time it renders.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_NAME = stringPreferencesKey("theme_name")
        val CORRECTION_LEVEL = intPreferencesKey("correction_level") // 0,1,2
        val TYPING_SOUNDS = booleanPreferencesKey("typing_sounds")
        val CORRECTION_ENABLED = booleanPreferencesKey("correction_enabled")
        val ACCEPTED_COUNT = intPreferencesKey("accepted_count")
        val REJECTED_COUNT = intPreferencesKey("rejected_count")
    }

    val themeName: Flow<String> = context.dataStore.data.map { it[Keys.THEME_NAME] ?: "Midnight Neon" }
    val correctionLevel: Flow<Int> = context.dataStore.data.map { it[Keys.CORRECTION_LEVEL] ?: 1 }
    val typingSounds: Flow<Boolean> = context.dataStore.data.map { it[Keys.TYPING_SOUNDS] ?: false }
    val correctionEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.CORRECTION_ENABLED] ?: true }
    val acceptedCount: Flow<Int> = context.dataStore.data.map { it[Keys.ACCEPTED_COUNT] ?: 0 }
    val rejectedCount: Flow<Int> = context.dataStore.data.map { it[Keys.REJECTED_COUNT] ?: 0 }

    /** "Vibe stat" shown in Settings: % of offered corrections the user actually accepted. */
    val acceptRatePercent: Flow<Int> = context.dataStore.data.map { prefs ->
        val accepted = prefs[Keys.ACCEPTED_COUNT] ?: 0
        val rejected = prefs[Keys.REJECTED_COUNT] ?: 0
        val total = accepted + rejected
        if (total == 0) 100 else ((accepted * 100) / total)
    }

    suspend fun recordAccepted() {
        context.dataStore.edit { it[Keys.ACCEPTED_COUNT] = (it[Keys.ACCEPTED_COUNT] ?: 0) + 1 }
    }

    suspend fun recordRejected() {
        context.dataStore.edit { it[Keys.REJECTED_COUNT] = (it[Keys.REJECTED_COUNT] ?: 0) + 1 }
    }

    suspend fun setThemeName(name: String) {
        context.dataStore.edit { it[Keys.THEME_NAME] = name }
    }

    suspend fun setCorrectionLevel(level: Int) {
        context.dataStore.edit { it[Keys.CORRECTION_LEVEL] = level }
    }

    suspend fun setTypingSounds(enabled: Boolean) {
        context.dataStore.edit { it[Keys.TYPING_SOUNDS] = enabled }
    }

    suspend fun setCorrectionEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.CORRECTION_ENABLED] = enabled }
    }
}
