package com.genzkeyboard.app.ime.theme

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * One theme = one complete "vibe". Adding a new theme later means adding one
 * object here, not touching any layout or key-rendering code.
 */
data class KeyboardTheme(
    val name: String,
    val background: Brush,
    val keyBackground: Color,
    val keyBackgroundPressed: Color,
    val keyGlow: Color,
    val keyText: Color,
    val accent: Brush,
    val suggestionBarBackground: Color,
    val suggestionChipBackground: Color,
    val suggestionChipText: Color,
    val keyCornerRadius: androidx.compose.ui.unit.Dp = 14.dp,
    val keyFontSize: androidx.compose.ui.unit.Dp = 16.dp, // used for scaling, actual text uses sp below
    val fontSizeSp: androidx.compose.ui.unit.TextUnit = 18.sp
)

object KeyboardThemes {

    val MidnightNeon = KeyboardTheme(
        name = "Midnight Neon",
        background = Brush.verticalGradient(listOf(Color(0xFF0D0D12), Color(0xFF16121F))),
        keyBackground = Color(0xFF1E1B2E),
        keyBackgroundPressed = Color(0xFF2D2548),
        keyGlow = Color(0xFFB388FF),
        keyText = Color(0xFFF2F0FF),
        accent = Brush.horizontalGradient(listOf(Color(0xFF7C4DFF), Color(0xFFFF4DD8))),
        suggestionBarBackground = Color(0xFF15121F),
        suggestionChipBackground = Color(0xFF261F3D),
        suggestionChipText = Color(0xFFE6DFFF)
    )

    val CyberLime = KeyboardTheme(
        name = "Cyber",
        background = Brush.verticalGradient(listOf(Color(0xFF060A08), Color(0xFF0B1410))),
        keyBackground = Color(0xFF111A15),
        keyBackgroundPressed = Color(0xFF1B2B22),
        keyGlow = Color(0xFFB6FF3C),
        keyText = Color(0xFFE8FFE0),
        accent = Brush.horizontalGradient(listOf(Color(0xFFB6FF3C), Color(0xFF32E6C4))),
        suggestionBarBackground = Color(0xFF0A120D),
        suggestionChipBackground = Color(0xFF17241B),
        suggestionChipText = Color(0xFFD4FFC2)
    )

    val Y2K = KeyboardTheme(
        name = "Y2K",
        background = Brush.verticalGradient(listOf(Color(0xFF120014), Color(0xFF1C0024))),
        keyBackground = Color(0xFF220A2E),
        keyBackgroundPressed = Color(0xFF3A1250),
        keyGlow = Color(0xFF00E5FF),
        keyText = Color(0xFFFFE8FB),
        accent = Brush.horizontalGradient(listOf(Color(0xFFFF6EC7), Color(0xFF00E5FF))),
        suggestionBarBackground = Color(0xFF17011F),
        suggestionChipBackground = Color(0xFF2B0E3A),
        suggestionChipText = Color(0xFFFFD6F6)
    )

    val all = listOf(MidnightNeon, CyberLime, Y2K)
}

val LocalKeyboardTheme = compositionLocalOf { KeyboardThemes.MidnightNeon }
